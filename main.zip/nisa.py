from tkinter import filedialog, Tk,END, Button, Text,Label,Entry,Canvas
from tkinter import messagebox
from cv2 import imread,imwrite,hconcat,vconcat,resize,INTER_AREA,split,merge
from PIL import Image, ImageTk
from os import getcwd
win = Tk()
win.title("judul program")
win.resizable(False,False)
size=[565,400]
win.geometry(str(size[0])+"x"+str(size[1]))
fileSelected=False


#opening file
def select_file():
    filetypes=(
        ('image files', '*.jpeg *.jpg *.png'),
        ('All files','*.*')
    )
    filename = filedialog.askopenfilename(
        title ="Open file",
        initialdir=getcwd(),
        filetypes=filetypes
    )
    print(type(filename))
    if filename!="":
        dim=imread(filename).shape[:2]
        if dim[0]<256 or dim[1]<256:
            messagebox.showerror(title="Open file error",message="File must bigger than 256x256 pixel in width and height")
            return
        if dim[0]>1080 or dim[1]>1920:
            messagebox.showerror(title="Open file error",message="File must smaller than 1920x1080 pixel in width and height")
            return
        filePath.delete('1.0',END)
        filePath.insert(END,filename)
        loadImage("input",filename)
        global fileLoc
        fileLoc=filename
        global fileSelected
        fileSelected=True
def save_file():
    f=filedialog.asksaveasfile(mode='w',defaultextension='.png',filetypes=[('PNG','*.png'),('JPEG','*.jpg')])
    if f is None:
        return
    print(f.name)

    #imwrite(f.name,b)  #b=variable file yang mau di save, aku -> b=numpy array (image)


def resizeImage(img):
    a,b=img.shape[:2]
    if a>b:
        r=a/256
        d=(int(b/r),256)
    else:
        r=b/256
        d=(256,int(a/r))
    return (resize(img,d,interpolation=INTER_AREA))
def loadImage(param,param2):
    if param==("input"):
        im=imread(param2)
        if im.shape[:2]!=(256,256):
            im=resizeImage(im)
        b,g,r=split(im)
        img=merge((r,g,b))
        img=Image.fromarray(img)
        inputImage= ImageTk.PhotoImage(img)
        inputImageLabel.configure(image=inputImage)
        inputImageLabel.image=inputImage
    if param==("output"):
        im=param2
        if im.shape[:2]!=(256,256):
            im=resizeImage(im)
        b,g,r=split(im)
        img=merge((r,g,b))
        img=Image.fromarray(img)
        outputImage= ImageTk.PhotoImage(img)
        outputImageLabel.configure(image=outputImage)
        outputImageLabel.configure()
        outputImageLabel.image=outputImage



openButton = Button(win, text='Open File', command=select_file)
encryptButton = Button(win, text='Encrypt', command=None) #encrypt-> fungsi enkripsi aku
decryptButton = Button(win,text='Decrypt', command=None) #decrypt-> fungsi dekripsi aku
saveButton=Button(win,text='Save file',command=save_file)
img=Image.open('blank.png')
inputImage= ImageTk.PhotoImage(img.resize((256,256)))
img2=Image.open('blank.png')
outputImage= ImageTk.PhotoImage(img2.resize((256,256)))


filePath=Text(win,height=1,width=45,)
passwordEntry=Entry(win,show='*',width=25)

directoryLabel = Label(win,text="File Directory")
passwordlabel = Label(win,text='Password')
inputImageLabel=Label(win,image=inputImage)
inputImageTextLabel=Label(win,text="gambar input")
outputImageLabel=Label(win,image=outputImage)
outputImageTextLabel=Label(win,text="gambar output")

inputImageTextLabel.place(x=int((10+256)/2)-30,y=size[1]-286)
inputImageLabel.place(in_=inputImageTextLabel,rely=0.5, x=-94,y=10)

outputImageTextLabel.place(x=int((10+256)/2)+286-30,y=size[1]-286)
outputImageLabel.place(in_=outputImageTextLabel,rely=0.5, x=-94,y=10)

directoryLabel.place(x=10,y=10)
filePath.place(x=120,y=10)
passwordlabel.place(x=10,y=40)
passwordEntry.place(x=120,y=40)
openButton.place(x=490,y=7)
encryptButton.place(x=10,y=70)
decryptButton.place(x=70,y=70)
saveButton.place(in_=decryptButton,relx=1.0,x=380,y=-5)

canvas=Canvas(win,bg="blue",height=300,width=300)
passwordEntryyy=Entry(canvas,show='*',width=10)

#open_button.pack(expand=True)

# im=Image.fromarray(img)
# Imgtk=ImageTk.PhotoImage(image=im)
# Label(win,image=imgtk).pack()
win.mainloop()